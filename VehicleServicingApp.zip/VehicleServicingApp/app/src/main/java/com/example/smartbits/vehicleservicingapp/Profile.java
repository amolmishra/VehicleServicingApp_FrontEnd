package com.example.smartbits.vehicleservicingapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.smartbits.vehicleservicingapp.loginandregistration.SQLiteHandler;

import java.util.HashMap;

public class Profile extends AppCompatActivity {

    private ImageView background;
    private ImageButton profile_pic;
    private TextView name;
    private TextView email;
    private ImageView plus;

    private SQLiteHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        db = new SQLiteHandler(getApplicationContext());

        setTitle("Profile");

        background = (ImageView) findViewById(R.id.header_cover_image);
        profile_pic = (ImageButton) findViewById(R.id.user_profile_photo);
        name = (TextView) findViewById(R.id.user_profile_name);
        email = (TextView) findViewById(R.id.user_profile_email);
        plus = (ImageView) findViewById(R.id.add_friend);

        HashMap<String, String> user = db.getUserDetails();
        String uname = user.get("name");
        String umail = user.get("email");

        name.setText(uname);
        email.setText(umail);
    }
}
