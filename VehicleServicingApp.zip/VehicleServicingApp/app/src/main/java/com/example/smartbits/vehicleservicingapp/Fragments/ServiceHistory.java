package com.example.smartbits.vehicleservicingapp.Fragments;


import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.smartbits.vehicleservicingapp.ExpandableListAdapter;
import com.example.smartbits.vehicleservicingapp.R;
import com.example.smartbits.vehicleservicingapp.loginandregistration.AppController;
import com.example.smartbits.vehicleservicingapp.loginandregistration.Config;
import com.example.smartbits.vehicleservicingapp.loginandregistration.LoginActivity;
import com.example.smartbits.vehicleservicingapp.loginandregistration.SQLiteHandler;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * A simple {@link Fragment} subclass.
 */
public class ServiceHistory extends Fragment {

    ExpandableListAdapter listAdapter;
    ExpandableListView expListView;
    List<String> listDataHeader;
    HashMap<String, List<String>> listDataChild;
    SQLiteHandler db;

    ProgressDialog progressDialog;


    public ServiceHistory() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_service_history, container, false);

        // get the listview
        expListView = (ExpandableListView) v.findViewById(R.id.lvExp);

        progressDialog = new ProgressDialog(getContext());
        progressDialog.setMessage("Fetching History...");
        progressDialog.show();

        // preparing list data
        prepareListData();


        new Handler().postDelayed(new Runnable() {

            /*
             * Showing splash screen with a timer. This will be useful when you
             * want to show case your app logo / company
             */

            @Override
            public void run() {
                // This method will be executed once the timer is over
                // Start your app main activity
                listAdapter = new ExpandableListAdapter(getContext(), listDataHeader, listDataChild);

                // setting list adapter
                expListView.setAdapter(listAdapter);

                progressDialog.hide();


            }
        }, 1000);





        // Listview Group expanded listener
        expListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {

            @Override
            public void onGroupExpand(int groupPosition) {
                Toast.makeText(getContext(),
                        listDataHeader.get(groupPosition) + " Expanded",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // get datebase object
        db = new SQLiteHandler(getContext());

        // Listview Group collasped listener
        expListView.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {

            @Override
            public void onGroupCollapse(int groupPosition) {
                Toast.makeText(getContext(),
                        listDataHeader.get(groupPosition) + " Collapsed",
                        Toast.LENGTH_SHORT).show();

            }
        });

        // Listview on child click listener
        expListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {

            @Override
            public boolean onChildClick(ExpandableListView parent, View v,
                                        int groupPosition, int childPosition, long id) {
                // TODO Auto-generated method stub
                Toast.makeText(
                        getContext(),
                        listDataHeader.get(groupPosition)
                                + " : "
                                + listDataChild.get(
                                listDataHeader.get(groupPosition)).get(
                                childPosition), Toast.LENGTH_SHORT)
                        .show();
                return false;
            }
        });

        // Inflate the layout for this fragment
        return v;
    }


    private void prepareListData() {
        listDataHeader = new ArrayList<String>();
        listDataChild = new HashMap<String, List<String>>();



        // TAG used to cancel the request
        String tag_string_req = "req_history";

        Log.d("Requesting History:", tag_string_req);

        StringRequest strReq = new StringRequest(Request.Method.POST, Config.URL_FETCH_APPOINTMENTS, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    boolean error = jsonObject.getBoolean("error");
                    if (!error) {
                        // service center list is downloaded
                        // Store the list in sqlite
                        JSONObject centers = jsonObject.getJSONObject("appointments");
                        Log.d("response: ", centers.toString());

                        for (int i = 1; i <= centers.length(); i++){
                            JSONObject serviceCenter = centers.getJSONObject(""+i);
                            String carid = serviceCenter.getString("registered_car_id");
                            String car = db.getCarById(carid);
                            listDataHeader.add(i-1, car);
                        }

                        for (int i = 1; i<=centers.length(); i++) {
                            int serviceid, centerid;
                            String carid, date, time, pickup;
                            JSONObject serviceCenter = centers.getJSONObject(""+i);

                            carid = serviceCenter.getString("registered_car_id");
                            String car = db.getCarById(carid);

                            serviceid = serviceCenter.getInt("serviceid");
                            date = serviceCenter.getString("date");
                            time = serviceCenter.getString("time");
                            centerid = serviceCenter.getInt("centerid");
                            pickup = serviceCenter.getString("pickup");

                            String center = db.getCenterById(centerid);
                            if (pickup.equalsIgnoreCase("y")) {
                                pickup = "Yes";
                            } else {
                                pickup = "No";
                            }

                            List<String> history = new ArrayList<>();
                            history.add(center);
                            history.add("Date: " + date);
                            history.add("Time: " + time);
                            history.add("Pickup&Delivery: " + pickup);
                            history.add("ServiceID: " + serviceid);

                            listDataChild.put(car, history);
                        }
                        Log.d(listDataHeader.toString(), listDataChild.toString());
                    } else {
                        Toast.makeText(getContext(), jsonObject.getString("error-msg"), Toast.LENGTH_LONG).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("username", LoginActivity.getUsername());
                return params;
            }
        };

        AppController.getmInstance().addToRequestQueue(strReq, tag_string_req);
    }

}
