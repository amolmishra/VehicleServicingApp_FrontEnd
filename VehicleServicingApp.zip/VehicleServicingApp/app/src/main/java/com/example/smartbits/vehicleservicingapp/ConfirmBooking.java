package com.example.smartbits.vehicleservicingapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.smartbits.vehicleservicingapp.loginandregistration.AppController;
import com.example.smartbits.vehicleservicingapp.loginandregistration.Config;
import com.example.smartbits.vehicleservicingapp.loginandregistration.LoginActivity;
import com.example.smartbits.vehicleservicingapp.loginandregistration.SQLiteHandler;

import org.json.JSONObject;

import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class ConfirmBooking extends AppCompatActivity {

    private Button btn_confirm;
    private TextView tv_name, tv_date, tv_time, tv_center, tv_pickupd;
    private String name, center, date, time;
    private boolean pickup_delivery;

    private ProgressDialog pDialog;

    private SQLiteHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_booking);

        setTitle("Confirm Booking");

        btn_confirm = (Button) findViewById(R.id.btn_confirm);
        tv_name = (TextView) findViewById(R.id.cf_veh_name);
        tv_center = (TextView) findViewById(R.id.cf_service_center);
        tv_center.setMovementMethod(new ScrollingMovementMethod());
        tv_date = (TextView) findViewById(R.id.cf_app_date);
        tv_time = (TextView) findViewById(R.id.cf_app_time);
        tv_pickupd = (TextView) findViewById(R.id.cf_pick_delivery);

        pDialog = new ProgressDialog(this);
        db = new SQLiteHandler(getApplicationContext());

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        name = bundle.getString("veh_name");
        center = bundle.getString("ser_center");
        date = bundle.getString("date");
        time = bundle.getString("time");
        if (bundle.getString("pickup").equals("true")) {
            pickup_delivery = true;
            tv_pickupd.setText("Yes");
        } else {
            pickup_delivery = false;
            tv_pickupd.setText("No");
        }

        tv_name.setText(name);
        tv_center.setText(center);
        tv_date.setText(date.toString());
        tv_time.setText(time.toString());


        btn_confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                bookServicing();
            }
        });
    }

    private void bookServicing() {
        String tag_string_req = "req_register";

        pDialog.setMessage("Booking...");
        showDialog();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Config.URL_BOOK_SERVICE, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("Booking", "BookResponse: " + response.toString());
                hideDialog();

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    boolean error = jsonObject.getBoolean("error");
                    if (!error) {
                        // booked successfully
                        String message = jsonObject.getString("message");
                        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();

                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(intent);
                        finish();

                    } else {
                        Toast.makeText(getApplicationContext(), jsonObject.getString("error-msg"), Toast.LENGTH_LONG).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                hideDialog();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                HashMap<String , String> user = db.getUserDetails();
                String username = user.get("username");
                String car[] = name.split("\\s+");
                String carId = db.getCarId(car[0], car[1]);
                String lines[] = center.split("[\\r\\n]");
                String centerId = db.getServiceCenterId(lines[1]);
                params.put("username", username);
                params.put("registered_car_id", carId);
                params.put("date", date);
                params.put("time", time);
                params.put("centerid", centerId);
                if (pickup_delivery) {
                    params.put("pickup", "Y" );
                } else {
                    params.put("pickup", "N" );
                }
                Log.d("paramsConfirmBooking:", params.toString());
                return params;
            }
        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(20 * 1000, 0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        AppController.getmInstance().addToRequestQueue(stringRequest, tag_string_req);


    }


    public void showDialog() {
        if (!pDialog.isShowing()) {
            pDialog.show();
        }
    }

    public void hideDialog() {
        if (pDialog.isShowing()) {
            pDialog.hide();
        }
    }
}
