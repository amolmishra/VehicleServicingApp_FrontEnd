package com.example.smartbits.vehicleservicingapp.loginandregistration;

import java.lang.reflect.Array;

/**
 * Created by root on 3/5/17.
 */

public class CarsListManager {
    public String []Chrevrolet  = {"Tavera","Spark","Beat","Cruze","Sail","Enjoy","Trailblazer"};
    public String [] Fiat = {"AbarthChevrolet","Avventura","Linea","Punto","UrbanCross"};
    public String [] Ford = {"Aspire","Ecosport","Endeavor","Fiesta","Figo","Mustang"};
    public String [] Hyundai = {"Creta","Eon","i10","i20","Tucson","Verna","Xcent"};
    public String [] Mahindra = {"Bolero","KUV100","Scorpio","Thar","Verito","XUV500","Xylo"};
    public String [] MarutiSuzuki = {"Alto","Ciaz","Dzire","Eeco","Ertiga","Omni","S-Coss","Swift","Vitara_Brezza","Wagon-R"};
    public String [] Skoda = {"Octavia","Rapid","Superb","Yeti"};
    public String [] TataMotors = {"Aria","Bolt","Indica","Indigo","Nano","Safari","Sumo", "Tiago"};
    public String [] Mitsubishi = {"Pajero","Montero","Lancer"};
    public String [] Nissan = {"Micra","Sunny","Terrano"};

    public String [][]Cars = {Chrevrolet, Fiat, Ford, Hyundai, Mahindra, MarutiSuzuki, Skoda, TataMotors, Mitsubishi, Nissan};

}
